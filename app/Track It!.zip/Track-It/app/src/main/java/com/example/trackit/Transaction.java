package com.example.trackit;
import android.graphics.Bitmap;
import android.net.Uri;

import java.util.Date;

public class Transaction {
    private String name;
    private String type;
    private double quantity;
    private Date date;
    private Uri image;

    //Constructor
    public Transaction(String name, String type, double quantity, Date date, Uri image){
        this.name = name;
        this.type = type;
        this.quantity = quantity;
        this.date = date;
        this.image = image;
    }

    public Transaction(){
        this.name = null;
        this.type = null;
        this.quantity = 0;
        this.date = null;
        this.image = null;
    }

    //Getters
    public String getName(){
        return this.name;
    }

    public String getType(){
        return this.type;
    }

    public double getQuantity(){
        return this.quantity;
    }

    public Date getDate(){
        return this.date;
    }

    public Uri getImage() { return this.image; }

    //Setters
    public void setName(String name){
        this.name = name;
    }

    public void setType(String type){
        this.type = type;
    }

    public void setQuantity(double quantity){
        this.quantity = quantity;
    }

    public void setDate(Date date){
        this.date = date;
    }

    public void setImage(Uri image) { this.image = image; }
}
